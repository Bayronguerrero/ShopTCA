//
//  ShopFeature.swift
//  ShopTCA
//
//  Created by Usuario invitado on 27/10/26.
//

import Foundation
import SwiftUI
import ComposableArchitecture

@Reducer
struct ShopFeature {
    
    @ObservableState
    struct State: Equatable {
        var products: [Product] = []
        var cart: [CartItem] = []
        var isShowingCart: Bool = false
        var isCheckingOut: Bool = false
        var checkoutMessage: String? = nil
        
        var cartTotal: Double {
            cart.reduce(0) { $0 + ($1.product.price * Double($1.quantity)) }
        }
        var cartItemCount: Int {
            cart.reduce(0) { $0 + $1.quantity }
        }
    }
    
    enum Action {
        case addToCart(Product)
        case decreaseQuantity(UUID) // 👈 Ahora recibe UUID
        case removeProduct(UUID)    // 👈 Ahora recibe UUID
        case setCartView(isPresented: Bool)
        case checkoutTapped
        case checkoutResponse(success: Bool)
        case dismissMessage
    }
    
    var body: some Reducer<State, Action> {
        Reduce { state, action in
            switch action {
            case let .addToCart(product):
                if let index = state.cart.firstIndex(where: { $0.product.id == product.id }) {
                    state.cart[index].quantity += 1
                } else {
                    state.cart.append(CartItem(product: product, quantity: 1))
                }
                return .none
                
            case let .decreaseQuantity(id):
                if let index = state.cart.firstIndex(where: { $0.product.id == id }) {
                    if state.cart[index].quantity > 1 {
                        state.cart[index].quantity -= 1
                    } else {
                        state.cart.remove(at: index)
                    }
                }
                return .none
                
            case let .removeProduct(id):
                state.cart.removeAll(where: { $0.product.id == id })
                return .none
                
            case let .setCartView(isPresented):
                state.isShowingCart = isPresented
                return .none
                
            case .checkoutTapped:
                state.isCheckingOut = true
                return .run { send in
                    try await Task.sleep(nanoseconds: 2_000_000_000)
                    await send(.checkoutResponse(success: true))
                }
                
            case let .checkoutResponse(success):
                state.isCheckingOut = false
                if success {
                    state.cart.removeAll()
                    state.isShowingCart = false
                    state.checkoutMessage = "¡Pago Exitoso! Gracias por tu compra."
                }
                return .none
                
            case .dismissMessage:
                state.checkoutMessage = nil
                return .none
            }
        }
    }
}
