//
//  ContentView.swift
//  ShopTCA
//
//  Created by Usuario invitado on 27/10/26.
//

import SwiftUI
import ComposableArchitecture

struct ContentView: View {
    @Bindable var store: StoreOf<ShopFeature>
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.96, blue: 0.98).ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Descubre")
                                .font(.system(size: 34, weight: .bold, design: .rounded))
                                .foregroundColor(.primary)
                            Text("Los mejores productos del año")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                        ForEach(store.products) { product in
                            ProductCardView(product: product) {
                                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                                    _ = store.send(.addToCart(product))
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        // 👈 CAMBIO AQUÍ: Enviamos true para abrir
                        _ = store.send(.setCartView(isPresented: true))
                    } label: {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: "cart.fill")
                                .font(.system(size: 22))
                                .foregroundColor(.primary)
                                .padding(10)
                                .background(Color.white)
                                .clipShape(Circle())
                                .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
                            
                            if store.cartItemCount > 0 {
                                Text("\(store.cartItemCount)")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundColor(.white)
                                    .frame(width: 20, height: 20)
                                    .background(Color.red)
                                    .clipShape(Circle())
                                    .offset(x: 5, y: -5)
                                    .transition(.scale)
                            }
                        }
                    }
                }
            }
            // 👈 CAMBIO AQUÍ: Usamos el valor que nos da SwiftUI
            .sheet(isPresented: Binding(
                get: { store.isShowingCart },
                set: { _ = store.send(.setCartView(isPresented: $0)) }
            )) {
                CartView(store: store)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            .alert("Aviso", isPresented: Binding(
                get: { store.checkoutMessage != nil },
                set: { if !$0 { _ = store.send(.dismissMessage) } }
            )) {
                Button("Aceptar") { _ = store.send(.dismissMessage) }
            } message: {
                Text(store.checkoutMessage ?? "")
            }
        }
    }
}

// (El ProductCardView se queda exactamente igual que en el mensaje anterior)
struct ProductCardView: View {
    let product: Product
    let addAction: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(LinearGradient(
                        colors: [Color.blue.opacity(0.15), Color.purple.opacity(0.15)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                
                Image(systemName: product.image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 60)
                    .foregroundColor(.blue)
                    .shadow(color: .blue.opacity(0.3), radius: 10, x: 0, y: 5)
            }
            .frame(height: 120)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(product.name)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
                    .lineLimit(1)
                
                Text(String(format: "$%.2f", product.price))
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundColor(.gray)
            }
            
            HStack {
                Spacer()
                Button(action: addAction) {
                    Image(systemName: "plus")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 35, height: 35)
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(color: .blue.opacity(0.4), radius: 5, x: 0, y: 3)
                }
            }
        }
        .padding(15)
        .background(Color.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 8)
    }
}

#Preview {
    ContentView(
        store: Store(
            initialState: ShopFeature.State(
                products: [
                    Product(name: "iPhone 15 Pro", price: 999.99, image: "iphone"),
                    Product(name: "MacBook Air", price: 1199.00, image: "laptopcomputer"),
                    Product(name: "AirPods Pro 2", price: 249.00, image: "airpodspro"),
                    Product(name: "Apple Watch", price: 399.00, image: "applewatch")
                ]
            )
        ) {
            ShopFeature()
        }
    )
}
