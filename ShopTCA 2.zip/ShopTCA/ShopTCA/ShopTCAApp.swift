//
//  ShopTCAApp.swift
//  ShopTCA
//
//  Created by Usuario invitado on 27/10/26.
//
import SwiftUI
import ComposableArchitecture

@main
struct ShopTCAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(
                store: Store(
                    initialState: ShopFeature.State(
                        products: [
                            Product(name: "iPhone 15 Pro", price: 999.99, image: "iphone"),
                            Product(name: "MacBook Air", price: 1199.00, image: "laptopcomputer"),
                            Product(name: "AirPods Pro 2", price: 249.00, image: "airpodspro"),
                            Product(name: "Apple Watch", price: 399.00, image: "applewatch"),
                            Product(name: "iPad Pro", price: 799.00, image: "ipad"),
                            Product(name: "HomePod Mini", price: 99.00, image: "homepod")
                        ]
                    )
                ) {
                    ShopFeature()
                }
            )
        }
    }
}
