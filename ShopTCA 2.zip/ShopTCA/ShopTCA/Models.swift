//
//  Models.swift
//  ShopTCA
//
//  Created by Usuario invitado on 27/10/26.
//

import Foundation

struct Product: Equatable, Identifiable {
    let id = UUID()
    let name: String
    let price: Double
    let image: String
}

struct CartItem: Equatable, Identifiable {
    var id: UUID { product.id }
    let product: Product
    var quantity: Int
}
