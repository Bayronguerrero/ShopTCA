//
//  CartView.swift
//  ShopTCA
//
//  Created by Usuario invitado on 27/10/26.
//

import SwiftUI
import ComposableArchitecture

struct CartView: View {
    @Bindable var store: StoreOf<ShopFeature>
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if store.cart.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "cart.badge.minus")
                            .font(.system(size: 70))
                            .foregroundColor(.gray.opacity(0.5))
                        Text("Tu carrito está vacío")
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundColor(.gray)
                    }
                    .frame(maxHeight: .infinity)
                } else {
                    List {
                        ForEach(store.cart) { item in
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle()
                                        .fill(Color.blue.opacity(0.1))
                                        .frame(width: 45, height: 45)
                                    Image(systemName: item.product.image)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.blue)
                                }
                                
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(item.product.name)
                                        .font(.system(size: 15, weight: .bold, design: .rounded))
                                    
                                    HStack(spacing: 12) {
                                        // Botón de Restar
                                        Button {
                                            _ = store.send(.decreaseQuantity(item.product.id)) // 👈 Enviamos el ID
                                        } label: {
                                            Image(systemName: "minus.circle.fill")
                                                .foregroundColor(.gray)
                                                .font(.title3)
                                        }
                                        .buttonStyle(.borderless) // 👈 FIX CRÍTICO
                                        
                                        Text("\(item.quantity)")
                                            .font(.system(size: 14, weight: .bold, design: .rounded))
                                            .frame(minWidth: 20)
                                        
                                        // Botón de Sumar
                                        Button {
                                            _ = store.send(.addToCart(item.product))
                                        } label: {
                                            Image(systemName: "plus.circle.fill")
                                                .foregroundColor(.blue)
                                                .font(.title3)
                                        }
                                        .buttonStyle(.borderless) // 👈 FIX CRÍTICO
                                    }
                                }
                                
                                Spacer()
                                
                                VStack(alignment: .trailing, spacing: 10) {
                                    Text(String(format: "$%.2f", item.product.price * Double(item.quantity)))
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                    
                                    // Botón de Eliminar
                                    Button {
                                        withAnimation {
                                            _ = store.send(.removeProduct(item.product.id)) // 👈 Enviamos el ID
                                        }
                                    } label: {
                                        Image(systemName: "trash")
                                            .foregroundColor(.red.opacity(0.8))
                                            .font(.system(size: 16))
                                    }
                                    .buttonStyle(.borderless) // 👈 FIX CRÍTICO
                                }
                            }
                            .padding(.vertical, 8)
                            .listRowSeparator(.hidden)
                        }
                        // 👈 Quitamos el .onDelete porque ya tenemos el botón de basura
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                }
                
                // Sección de Total y Pago
                VStack(spacing: 15) {
                    HStack {
                        Text("Total a pagar:")
                            .font(.headline)
                            .foregroundColor(.gray)
                        Spacer()
                        Text(String(format: "$%.2f", store.cartTotal))
                            .font(.system(size: 28, weight: .heavy, design: .rounded))
                            .foregroundColor(.primary)
                    }
                    
                    Button(action: {
                        _ = store.send(.checkoutTapped)
                    }) {
                        HStack {
                            if store.isCheckingOut {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Image(systemName: "creditcard.fill")
                                Text("Pagar Ahora")
                                    .font(.system(size: 18, weight: .bold, design: .rounded))
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: store.cart.isEmpty ? [Color.gray, Color.gray.opacity(0.8)] : [Color.green, Color.mint],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(18)
                        .shadow(color: store.cart.isEmpty ? .clear : Color.green.opacity(0.4), radius: 10, x: 0, y: 5)
                    }
                    .disabled(store.cart.isEmpty || store.isCheckingOut)
                }
                .padding(20)
                .background(Color.white)
                .cornerRadius(25)
                .shadow(color: .black.opacity(0.05), radius: 20, x: 0, y: -5)
            }
            .background(Color(red: 0.96, green: 0.96, blue: 0.98).ignoresSafeArea())
            .navigationTitle("Mi Carrito")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Cerrar") {
                        _ = store.send(.setCartView(isPresented: false))
                    }
                    .font(.headline)
                }
            }
        }
    }
}

#Preview {
    CartView(
        store: Store(
            initialState: ShopFeature.State(
                products: [],
                cart: [
                    CartItem(product: Product(name: "iPhone 15 Pro", price: 999.99, image: "iphone"), quantity: 1),
                    CartItem(product: Product(name: "MacBook Air", price: 1199.00, image: "laptopcomputer"), quantity: 2)
                ]
            )
        ) {
            ShopFeature()
        }
    )
}
